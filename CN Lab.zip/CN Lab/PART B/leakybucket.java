import java.util.*;
class Leaky {
	public static void main(String[] args) throws Exception{
		int k=0;
		int a[]={2,4,5,3,0};;
		int buckRem =0,sent,recv;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the Bucket Size");
		int buckSize=in.nextInt();
		System.out.println("Enter the Transmission Rate");
		int rate=in.nextInt();
		System.out.println("Enter the number of clock ticks");
		int n=in.nextInt();
		System.out.println("Clock PacSize Accepted Sent Remaining");
		for (int i=0;i<n;i++ ) {
			if (a[i]!=0) {
				if(buckRem+a[i]>buckSize)
					recv=-1;
				else {
					recv=a[i];
					buckRem+=a[i];
				}
			}
			else 
				recv=0;
			if(buckRem!=0){
				Thread.sleep(1000);
				if(buckRem<rate)
				{
					sent=buckRem;
					buckRem=0;
				}
				else
				{
					sent=rate;
					buckRem=buckRem-rate;
				}
			}
			else
				sent=0;
			if (recv==-1)
				System.out.println((i+1)+"\t"+a[i]+"\tDropped\t"+sent+"\t"+buckRem);
			else
				System.out.println((i+1)+"\t"+a[i]+"\t"+recv+"\t"+sent+"\t"+buckRem);
		}
	}
}