import java.net.*;
import java.io.*;
class udpclient
{
	public static void main(String[] args) throws Exception {
		DatagramSocket clientSocket=new DatagramSocket();
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		InetAddress IPAddress = InetAddress.getByName("localhost");
		byte receiveData[]=new byte[1024];
		byte sendData[]=new byte[1024];
		String sentence = "Request from Client...";
		sendData=sentence.getBytes();
		DatagramPacket sendPacket=new DatagramPacket(sendData,sendData.length,IPAddress,9876);
		clientSocket.send(sendPacket);
		DatagramPacket receivePacket = new DatagramPacket(receiveData,receiveData.length);
		clientSocket.receive(receivePacket);
		String recvdata=new String(receivePacket.getData());
		System.out.println("Message from server : "+recvdata);
		clientSocket.close();
	}
}
