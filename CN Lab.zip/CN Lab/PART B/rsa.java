import java.util.*;
class RSA {
	public static void main(String[] args) {
		int PT[]=new int[100];
		int CT[]=new int[100];
		int n,d,p,i,q,z,e=0;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter 2 large prime numbers");
		p=in.nextInt();
		q=in.nextInt();
		n=p*q;
		z=(p-1)*(q-1);
		for(e=2;e<z;e++) 
			if(gcd(e,z)==1)
			break;
		for(d=1;d<=z;d++) 
			if((e*d-1)%z==0)
				break;
		System.out.println("Enter the message");
		String msg=in.next();
		System.out.println("Public key=("+e+","+n+")");
		System.out.println("Private key=("+d+","+n+")");
		for(i=0;i<msg.length();i++)
			PT[i]=(int)msg.charAt(i);
		for(i=0;i<msg.length();i++)
			CT[i]=endecoder(PT[i],e,n);
		System.out.print("Cipher Text=");
		for (i=0;i<msg.length();i++ )
		System.out.print(CT[i]);
        System.out.println();
        System.out.print("Plain Text=");
        for(i=0;i<msg.length();i++)
			PT[i]=endecoder(CT[i],d,n);
		for (i=0;i<msg.length();i++)
		System.out.print((char)PT[i]);
        System.out.println();
        }
        public static int endecoder(int x,int y,int n)
        {
        	int k=1;
        	for(int j=1;j<=y;j++)
        		k=k*x%n;
        	return k;
        }
        public static int gcd(int a,int b)
        {
        	if(b==0)
        		return a;
        	else 
        		return gcd(b,(a%b));
        }
}