import java.util.*;
public class crc{
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		String data_s=new String();
		String divisor_s=new String();
		String data_r=new String();
		int n;
		System.out.println("Enter the Data Bits :");
		data_s=in.nextLine();
		System.out.println("Enter the divisor Bits :");
		divisor_s=in.nextLine();
		int data[]= new int[data_s.length()+divisor_s.length()-1];
		for (int i=0;i<data_s.length();i++ ) {
			data[i]=data_s.charAt(i)-48;
		}
		int divisor[] =new int[divisor_s.length()];
		for (int i=0;i<divisor_s.length();i++) {
			divisor[i]=divisor_s.charAt(i)-48;
		}
		int rem[]=divide(data,divisor);
		for (int i=0;i<rem.length-1;i++ ) {
			data[data_s.length()+i]=rem[i];
		}
		for (int i=0;i<data.length;i++) {
			System.out.print(data[i]);
		}
		System.out.println();
		System.out.println("Enter the message recieved");
		data_r=in.nextLine();
		int data1[]= new int[data_r.length()+divisor_s.length()-1];
		for (int i=0;i<data_r.length();i++ ) {
			data1[i]=data_r.charAt(i)-48;
		}
		int rem1[]=divide(data1,divisor);
		int flag=0;
		for (int i=0;i<rem1.length;i++ ) {
			if(rem1[i]!=0)
				flag=1;
		}
		if(flag==0) {
			System.out.println("No error in the message");
		}
		else {
			System.out.println("Error in the message");
		}
	}
	static int[] divide(int data[],int divisor[]) {
		int reminder[]=new int[divisor.length];
		System.arraycopy(data,0,reminder,0,divisor.length);
		for (int i=0;i<data.length-(divisor.length-1); i++) {
			if (reminder[0]==1) {
				for (int j=1;j<divisor.length;j++ ) {
					reminder[j-1]=Exor(reminder[j],divisor[j]);
				}
			}
			else {
				for (int j=1;j<divisor.length;j++ ) {
					reminder[j-1]=Exor(reminder[j],0);
				}
			}
			if (i<data.length-(divisor.length+1)) {
				reminder[divisor.length-1]=data[i+divisor.length];
			}
			}
			return reminder;
		}
		static int Exor(int a,int b) {
			if(a==b){
				return 0;
			}
			return 1;
		}
	}
