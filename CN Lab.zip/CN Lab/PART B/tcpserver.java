import java.net.*;
import java.io.*;
class tcpserver
{
	public static void main(String[] args) throws Exception {
		ServerSocket sersock = new ServerSocket(4000);
		System.out.println("Server ready for connection");
		Socket sock =sersock.accept(); //Binding with port 4000
		System.out.println("connection successful");
		InputStream istream=sock.getInputStream(); //Reading filename from client
		BufferedReader fileRead=new BufferedReader(new InputStreamReader(istream));
		String fname =fileRead.readLine();
		BufferedReader contentRead=new BufferedReader(new FileReader(fname));
		OutputStream ostream=sock.getOutputStream();
		PrintWriter pwrite=new PrintWriter(ostream,true);
		String str;
		while((str=contentRead.readLine())!=null) //Reading from file Line by Line
		{
			pwrite.println(str); //Sending each line to client
		}
		sock.close();
		sersock.close();
		pwrite.close();
		fileRead.close();
		contentRead.close();
	}
}